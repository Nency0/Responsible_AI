```python
!pip install pdpbox
```

    Requirement already satisfied: pdpbox in /opt/anaconda3/lib/python3.9/site-packages (0.2.1)
    Requirement already satisfied: joblib in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (1.2.0)
    Requirement already satisfied: pandas in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (1.4.4)
    Requirement already satisfied: matplotlib==3.1.1 in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (3.1.1)
    Requirement already satisfied: scipy in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (1.9.1)
    Requirement already satisfied: sklearn in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (0.0.post1)
    Requirement already satisfied: psutil in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (5.9.0)
    Requirement already satisfied: numpy in /opt/anaconda3/lib/python3.9/site-packages (from pdpbox) (1.21.5)
    Requirement already satisfied: cycler>=0.10 in /opt/anaconda3/lib/python3.9/site-packages (from matplotlib==3.1.1->pdpbox) (0.11.0)
    Requirement already satisfied: python-dateutil>=2.1 in /opt/anaconda3/lib/python3.9/site-packages (from matplotlib==3.1.1->pdpbox) (2.8.2)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /opt/anaconda3/lib/python3.9/site-packages (from matplotlib==3.1.1->pdpbox) (3.0.9)
    Requirement already satisfied: kiwisolver>=1.0.1 in /opt/anaconda3/lib/python3.9/site-packages (from matplotlib==3.1.1->pdpbox) (1.4.2)
    Requirement already satisfied: pytz>=2020.1 in /opt/anaconda3/lib/python3.9/site-packages (from pandas->pdpbox) (2022.1)
    Requirement already satisfied: six>=1.5 in /opt/anaconda3/lib/python3.9/site-packages (from python-dateutil>=2.1->matplotlib==3.1.1->pdpbox) (1.16.0)



```python
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
```


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
from scipy import spatial
from sklearn.model_selection import train_test_split
```


```python
def model_metrics(y_true, y_pred_prob_ww, y_pred_prob_wow, Y_pred_binary_ww, Y_pred_binary_wow, X_test):
    """
    Model accuracy metrics for models with sample weights and without sample weights

    Parameters
    ----------

    :param y_true: Actual binary outcome
    :param y_pred_prob_ww: predicted probabilities with weights
    :param y_pred_prob_wow: predicted probabilities without weights
    :param Y_pred_binary_ww: predicted binary outcome with weights
    :param Y_pred_binary_wow: predicted binary outcome without weights
    :param X_test: Xtest data [not being used here]
    :return: roc, gini, avg precision, precision, sensitivity, tnr, fnr, f1, cost


    Examples
    --------
    model_perf=[model_metrics(y_test, y_pred_prob_ww, y_pred_prob_wow,
                          y_pred_ww, y_pred_wow, X_test1)]

    """
    tn_ww, fp_ww, fn_ww, tp_ww = confusion_matrix(y_true, Y_pred_binary_ww).ravel() #y_true, y_pred
    tn_wow, fp_wow, fn_wow, tp_wow = confusion_matrix(y_true, Y_pred_binary_wow).ravel()

    roc_ww = roc_auc_score(y_true, y_pred_prob_ww)
    roc_wow = roc_auc_score(y_true, y_pred_prob_wow)

    gini_ww = gini_normalized(y_true, y_pred_prob_ww)
    gini_wow = gini_normalized(y_true, y_pred_prob_wow)


    ps_ww = average_precision_score(y_true, Y_pred_binary_ww)
    ps_wow = average_precision_score(y_true, Y_pred_binary_wow)


    prec_ww = tp_ww / (tp_ww + fp_ww)
    prec_wow = tp_wow / (tp_wow + fp_wow)


    sensitivity_ww = tp_ww/(tp_ww+fn_ww)
    sensitivity_wow = tp_wow/(tp_wow+fn_wow)

    tnr_ww = tn_ww/(tn_ww + fp_ww)
    tnr_wow = tn_wow/(tn_wow + fp_wow)


    fnr_ww = fn_ww/(fn_ww+tp_ww)
    fnr_wow = fn_wow/(fn_wow+tp_wow)

    f1_ww = (2*tp_ww)/((2*tp_ww)+fp_ww+fn_ww)
    f1_wow = (2*tp_wow)/((2*tp_wow)+fp_wow+fn_wow)



    cost_ww = (fp_ww*700) + (fn_ww*300)
    cost_wow = (fp_wow*700) + (fn_wow*300)

    return roc_ww, gini_ww, ps_ww, prec_ww, sensitivity_ww, fnr_ww, f1_ww, cost_ww, roc_wow, gini_wow, ps_wow,  prec_wow, sensitivity_wow, fnr_wow, f1_wow, cost_wow

```


```python
def fair_metrics(y_actual, y_pred_prob, y_pred_binary, X_test, protected_group_name,
                 adv_val, disadv_val):
    """
    Fairness performance metrics for a model to compare advantageous and disadvantageous groups of a protected variable

    Parameters
    ----------

    :param y_actual: Actual binary outcome
    :param y_pred_prob: predicted probabilities
    :param y_pred_binary: predicted binary outcome
    :param X_test: Xtest data
    :param protected_group_name: Sensitive feature
    :param adv_val: Priviliged value of protected label
    :param disadv_val: Unpriviliged value of protected label
    :return: roc, avg precision, Eq of Opportunity, Equalised Odds, Precision/Predictive Parity, Demographic Parity, Avg Odds Diff,
            Predictive Equality, Treatment Equality

    Examples
    --------
    fairness_metrics=[fair_metrics(y_test, y_pred_prob, y_pred,
                     X_test, choice, adv_val, disadv_val)]


    """
    tn_adv, fp_adv, fn_adv, tp_adv = confusion_matrix(
        y_actual[X_test[protected_group_name] == adv_val],
        y_pred_binary[X_test[protected_group_name] == adv_val]).ravel()

    tn_disadv, fp_disadv, fn_disadv, tp_disadv = confusion_matrix(
        y_actual[X_test[protected_group_name] == disadv_val],
        y_pred_binary[X_test[protected_group_name] == disadv_val]).ravel()

    # Receiver operating characteristic
    roc_adv = roc_auc_score(y_actual[X_test[protected_group_name] == adv_val],
                            y_pred_prob[X_test[protected_group_name] == adv_val])
    roc_disadv = roc_auc_score(y_actual[X_test[protected_group_name] == disadv_val],
                               y_pred_prob[X_test[protected_group_name] == disadv_val])

    roc_diff = abs(roc_disadv - roc_adv)

    # Average precision score
    ps_adv = average_precision_score(
        y_actual[X_test[protected_group_name] == adv_val],
        y_pred_prob[X_test[protected_group_name] == adv_val])
    ps_disadv = average_precision_score(
        y_actual[X_test[protected_group_name] == disadv_val],
        y_pred_prob[X_test[protected_group_name] == disadv_val])

    ps_diff = abs(ps_disadv - ps_adv)

    # Equal Opportunity - advantageous and disadvantageous groups have equal FNR
    FNR_adv = fn_adv / (fn_adv + tp_adv)
    FNR_disadv = fn_disadv / (fn_disadv + tp_disadv)
    EOpp_diff = abs(FNR_disadv - FNR_adv)

    # Predictive equality  - advantageous and disadvantageous groups have equal FPR
    FPR_adv = fp_adv / (fp_adv + tn_adv)
    FPR_disadv = fp_disadv / (fp_disadv + tn_disadv)
    pred_eq_diff = abs(FPR_disadv - FPR_adv)

    # Equalised Odds - advantageous and disadvantageous groups have equal TPR + FPR
    TPR_adv = tp_adv / (tp_adv + fn_adv)
    TPR_disadv = tp_disadv / (tp_disadv + fn_disadv)
    EOdds_diff = abs((TPR_disadv + FPR_disadv) - (TPR_adv + FPR_adv))

    # Predictive Parity - advantageous and disadvantageous groups have equal PPV/Precision (TP/TP+FP)
    prec_adv = (tp_adv)/(tp_adv + fp_adv)
    
    prec_disadv = (tp_disadv)/(tp_disadv + fp_disadv)
    
    prec_diff = abs(prec_disadv - prec_adv)
    

    # Demographic Parity - ratio of (instances with favourable prediction) / (total instances)
    demo_parity_adv = (tp_adv + fp_adv) / (tn_adv + fp_adv + fn_adv + tp_adv)
    demo_parity_disadv = (tp_disadv + fp_disadv) / \
        (tn_disadv + fp_disadv + fn_disadv + tp_disadv)
    demo_parity_diff = abs(demo_parity_disadv - demo_parity_adv)

    # Average of Difference in FPR and TPR for advantageous and disadvantageous groups
    AOD = 0.5*((FPR_disadv - FPR_adv) + (TPR_disadv - TPR_adv))

    # Treatment Equality  - advantageous and disadvantageous groups have equal ratio of FN/FP
    

    return [('Equal Opps', EOpp_diff),
            ('PredEq', pred_eq_diff), ('Equal Odds',
                                       EOdds_diff), 
            ('DemoParity', demo_parity_diff), ('AOD', abs(AOD))]

```


```python
def acf_fair_metrics(tn_disadv, fp_disadv, fn_disadv, tp_disadv, tn_adv, fp_adv, fn_adv, tp_adv):
    """
    Fairness performance metrics for a additive counterfactually fair model to compare advantageous and
    disadvantageous groups of a protected variable

    :param tn_disadv: disadvantaged group's true negative
    :param fp_disadv: disadvantaged group's false positive
    :param fn_disadv: disadvantaged group's false negative
    :param tp_disadv: disadvantaged group's true positive
    :param tn_adv: advantaged group's true negative
    :param fp_adv: advantaged group's false positive
    :param fn_adv: advantaged group's false negative
    :param tp_adv: advantaged group's true positive
    :return: Equal Opportunity, Predictive Equality, Equalised Odds, Precision/Predictive Parity, Demographic Parity,
        Avg Odds Diff, Treatment Equality

    Examples
    --------
    acf_metrics=acf_fair_metrics(tn_disadv, fp_disadv, fn_disadv, tp_disadv, tn_adv, fp_adv, fn_adv, tp_adv)
    """

    # Equal Opportunity - advantageous and disadvantageous groups have equal FNR
    FNR_adv = fn_adv / (fn_adv + tp_adv)
    FNR_disadv = fn_disadv / (fn_disadv + tp_disadv)
    EOpp_diff = abs(FNR_disadv - FNR_adv)

    # Predictive equality  - advantageous and disadvantageous groups have equal FPR
    FPR_adv = fp_adv / (fp_adv + tn_adv)
    FPR_disadv = fp_disadv / (fp_disadv + tn_disadv)
    pred_eq_diff = abs(FPR_disadv - FPR_adv)

    # Equalised Odds - advantageous and disadvantageous groups have equal TPR + FPR
    TPR_adv = tp_adv / (tp_adv + fn_adv)
    TPR_disadv = tp_disadv / (tp_disadv + fn_disadv)
    EOdds_diff = abs((TPR_disadv + FPR_disadv) - (TPR_adv + FPR_adv))

    # Predictive Parity - advantageous and disadvantageous groups have equal PPV/Precision (TP/TP+FP)
    prec_adv = (tp_adv)/(tp_adv + fp_adv)
    prec_disadv = (tp_disadv)/(tp_disadv + fp_disadv)
    prec_diff = abs(prec_disadv - prec_adv)

    # Demographic Parity - ratio of (instances with favourable prediction) / (total instances)
    demo_parity_adv = (tp_adv + fp_adv) / (tn_adv + fp_adv + fn_adv + tp_adv)
    demo_parity_disadv = (tp_disadv + fp_disadv) / \
        (tn_disadv + fp_disadv + fn_disadv + tp_disadv)
    demo_parity_diff = abs(demo_parity_disadv - demo_parity_adv)

    # Average of Difference in FPR and TPR for advantageous and disadvantageous groups
    AOD = 0.5*((FPR_disadv - FPR_adv) + (TPR_disadv - TPR_adv))

    # Treatment Equality  - advantageous and disadvantageous groups have equal ratio of FN/FP
    TE_adv = fn_adv/fp_adv
    TE_disadv = fn_disadv/fp_disadv
    TE_diff = abs(TE_disadv - TE_adv)

    return [('Equal Opps', EOpp_diff),
            ('PredEq', pred_eq_diff), ('Equal Odds',
                                       EOdds_diff), 
            ('DemoParity', demo_parity_diff), ('AOD', abs(AOD))]


```


```python
raw_data=pd.read_excel("default of credit card clients.xls")
raw_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>MARRIAGE</th>
      <th>AGE</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>...</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>20000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>24</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>120000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>26</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3272</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>90000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>14331</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>50000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28314</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>57</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>20940</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>




```python
raw_data.isnull().sum()
```




    ID                            0
    LIMIT_BAL                     0
    SEX                           0
    EDUCATION                     0
    MARRIAGE                      0
    AGE                           0
    PAY_0                         0
    PAY_2                         0
    PAY_3                         0
    PAY_4                         0
    PAY_5                         0
    PAY_6                         0
    BILL_AMT1                     0
    BILL_AMT2                     0
    BILL_AMT3                     0
    BILL_AMT4                     0
    BILL_AMT5                     0
    BILL_AMT6                     0
    PAY_AMT1                      0
    PAY_AMT2                      0
    PAY_AMT3                      0
    PAY_AMT4                      0
    PAY_AMT5                      0
    PAY_AMT6                      0
    default payment next month    0
    dtype: int64




```python
# # raw_data['EDUCATION'] = np.where((raw_data['EDUCATION'] == 3) or (raw_data['EDUCATION'] == 4),0, 1)
# raw_data['EDUCATION'].unique()
```


```python

for index,each in raw_data.iterrows():
#     print(each['SEX'])
    if each['EDUCATION']==0:
        each['EDUCATION']=0
    elif each['EDUCATION']==1:
        each['EDUCATION']=0
    elif each['EDUCATION']==2:
        each['EDUCATION']=0
    elif each['EDUCATION']==3:
        each['EDUCATION']=0 
    else:
        each['EDUCATION']=1
        
    
```


```python
raw_data['EDUCATION'].unique()
```




    array([0, 1])




```python
def circle(result):
        r = 1
        d = 10 * r * (1 - result)
        circle1=plt.Circle((0, 0), r, alpha=.2)
        circle2=plt.Circle((d, 0), r, alpha=.2)
        plt.ylim([-1.1, 1.1])
        plt.xlim([-1.1, 1.1 + d])
        fig = plt.gcf()
        fig.gca().add_artist(circle1)
        fig.gca().add_artist(circle2)
```


```python
def cosine_similarity(df,n,lower_limit,upper_limit):
    for i in np.arange(lower_limit,upper_limit):
        result = 1 - spatial.distance.cosine(df[n], df.iloc[:,i])
        print ('cosine distance between {}  and {}'.format(n,df.columns[i]), result)
        circle(result)
```


```python
cosine_similarity(raw_data,'SEX',6,25)
```

    cosine distance between SEX  and PAY_0 -0.031026453342862137
    cosine distance between SEX  and PAY_2 -0.12673275318740096
    cosine distance between SEX  and PAY_3 -0.1506606179232488
    cosine distance between SEX  and PAY_4 -0.1946531643353595
    cosine distance between SEX  and PAY_5 -0.23438130766522436
    cosine distance between SEX  and PAY_6 -0.24716856301743184
    cosine distance between SEX  and BILL_AMT1 0.5381628685249796
    cosine distance between SEX  and BILL_AMT2 0.536262257289651
    cosine distance between SEX  and BILL_AMT3 0.5307980386715532
    cosine distance between SEX  and BILL_AMT4 0.5284754127756511
    cosine distance between SEX  and BILL_AMT5 0.5244448531312623
    cosine distance between SEX  and BILL_AMT6 0.5187282041609482
    cosine distance between SEX  and PAY_AMT1 0.3094086808866252
    cosine distance between SEX  and PAY_AMT2 0.2376822373059443
    cosine distance between SEX  and PAY_AMT3 0.26975278084977883
    cosine distance between SEX  and PAY_AMT4 0.2809817050288854
    cosine distance between SEX  and PAY_AMT5 0.28619676716369125
    cosine distance between SEX  and PAY_AMT6 0.2684971790856866
    cosine distance between SEX  and default payment next month 0.43957389201265396



    
![png](output_13_1.png)
    



```python
cosine_similarity(raw_data,'MARRIAGE',6,25)
```

    cosine distance between MARRIAGE  and PAY_0 -0.007734807054950332
    cosine distance between MARRIAGE  and PAY_2 -0.0975843214210077
    cosine distance between MARRIAGE  and PAY_3 -0.12004676565067474
    cosine distance between MARRIAGE  and PAY_4 -0.16541832017229474
    cosine distance between MARRIAGE  and PAY_5 -0.2057013890451045
    cosine distance between MARRIAGE  and PAY_6 -0.2219790687790486
    cosine distance between MARRIAGE  and BILL_AMT1 0.535120466509041
    cosine distance between MARRIAGE  and BILL_AMT2 0.533146912965392
    cosine distance between MARRIAGE  and BILL_AMT3 0.5252861155209902
    cosine distance between MARRIAGE  and BILL_AMT4 0.5227532292019536
    cosine distance between MARRIAGE  and BILL_AMT5 0.5170362435062202
    cosine distance between MARRIAGE  and BILL_AMT6 0.5124106476755194
    cosine distance between MARRIAGE  and PAY_AMT1 0.30486393912635856
    cosine distance between MARRIAGE  and PAY_AMT2 0.23341626376316682
    cosine distance between MARRIAGE  and PAY_AMT3 0.2686051582423531
    cosine distance between MARRIAGE  and PAY_AMT4 0.27519107203331994
    cosine distance between MARRIAGE  and PAY_AMT5 0.2836932439768317
    cosine distance between MARRIAGE  and PAY_AMT6 0.2647966683382621
    cosine distance between MARRIAGE  and default payment next month 0.4389320887083368



    
![png](output_14_1.png)
    



```python
cosine_similarity(raw_data,'default payment next month',0,25)
```

    cosine distance between default payment next month  and ID 0.40115550978898296
    cosine distance between default payment next month  and LIMIT_BAL 0.288836447523904
    cosine distance between default payment next month  and SEX 0.43957389201265396
    cosine distance between default payment next month  and EDUCATION 0.019012219723353208
    cosine distance between default payment next month  and MARRIAGE 0.4389320887083368
    cosine distance between default payment next month  and AGE 0.4582936368100765
    cosine distance between default payment next month  and PAY_0 0.279609256316948
    cosine distance between default payment next month  and PAY_2 0.1789179580621184
    cosine distance between default payment next month  and PAY_3 0.1409462779531856
    cosine distance between default payment next month  and PAY_4 0.10061339025795413
    cosine distance between default payment next month  and PAY_5 0.06782853096865171
    cosine distance between default payment next month  and PAY_6 0.04445149277378457
    cosine distance between default payment next month  and BILL_AMT1 0.254348582623235
    cosine distance between default payment next month  and BILL_AMT2 0.25705907977500564
    cosine distance between default payment next month  and BILL_AMT3 0.25363181495846865
    cosine distance between default payment next month  and BILL_AMT4 0.25502167454131963
    cosine distance between default payment next month  and BILL_AMT5 0.254933755578976
    cosine distance between default payment next month  and BILL_AMT6 0.25310202590641007
    cosine distance between default payment next month  and PAY_AMT1 0.0912731025346939
    cosine distance between default payment next month  and PAY_AMT2 0.0669946466134006
    cosine distance between default payment next month  and PAY_AMT3 0.0862325519347934
    cosine distance between default payment next month  and PAY_AMT4 0.09053888537250387
    cosine distance between default payment next month  and PAY_AMT5 0.09454280898272638
    cosine distance between default payment next month  and PAY_AMT6 0.08736670251095247
    cosine distance between default payment next month  and default payment next month 1



    
![png](output_15_1.png)
    



```python
cosine_similarity(raw_data,'EDUCATION',6,25)
```

    cosine distance between EDUCATION  and PAY_0 -0.025314561967561877
    cosine distance between EDUCATION  and PAY_2 -0.0440878424972877
    cosine distance between EDUCATION  and PAY_3 -0.048885672812877035
    cosine distance between EDUCATION  and PAY_4 -0.051470671595143624
    cosine distance between EDUCATION  and PAY_5 -0.05377302427249453
    cosine distance between EDUCATION  and PAY_6 -0.06167404607969673
    cosine distance between EDUCATION  and BILL_AMT1 0.10198925003601145
    cosine distance between EDUCATION  and BILL_AMT2 0.0971546315753622
    cosine distance between EDUCATION  and BILL_AMT3 0.094505446079582
    cosine distance between EDUCATION  and BILL_AMT4 0.08762876392511776
    cosine distance between EDUCATION  and BILL_AMT5 0.0796083349773945
    cosine distance between EDUCATION  and BILL_AMT6 0.07191516460912761
    cosine distance between EDUCATION  and PAY_AMT1 0.04397786948302307
    cosine distance between EDUCATION  and PAY_AMT2 0.04119710111805186
    cosine distance between EDUCATION  and PAY_AMT3 0.05576792690856669
    cosine distance between EDUCATION  and PAY_AMT4 0.037550898740830174
    cosine distance between EDUCATION  and PAY_AMT5 0.044509291145055974
    cosine distance between EDUCATION  and PAY_AMT6 0.050557142048487824
    cosine distance between EDUCATION  and default payment next month 0.019012219723353208



    
![png](output_16_1.png)
    



```python
cosine_similarity(raw_data,'AGE',6,25)
```

    cosine distance between AGE  and PAY_0 -0.024298251544266236
    cosine distance between AGE  and PAY_2 -0.12000819607712288
    cosine distance between AGE  and PAY_3 -0.14633737647441913
    cosine distance between AGE  and PAY_4 -0.19179771789188838
    cosine distance between AGE  and PAY_5 -0.23451932511697504
    cosine distance between AGE  and PAY_6 -0.24940218262820713
    cosine distance between AGE  and BILL_AMT1 0.5643227867083552
    cosine distance between AGE  and BILL_AMT2 0.5614412134139822
    cosine distance between AGE  and BILL_AMT3 0.5542898811725712
    cosine distance between AGE  and BILL_AMT4 0.5508339362195074
    cosine distance between AGE  and BILL_AMT5 0.545205648798018
    cosine distance between AGE  and BILL_AMT6 0.5390581107113878
    cosine distance between AGE  and PAY_AMT1 0.31937640906542175
    cosine distance between AGE  and PAY_AMT2 0.24621144087820668
    cosine distance between AGE  and PAY_AMT3 0.28244313231187634
    cosine distance between AGE  and PAY_AMT4 0.2900891282000462
    cosine distance between AGE  and PAY_AMT5 0.29555089868456264
    cosine distance between AGE  and PAY_AMT6 0.27717305278151605
    cosine distance between AGE  and default payment next month 0.4582936368100765



    
![png](output_17_1.png)
    


#### No proxy feature. checked ok

#### check data bias


```python
raw_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'MARRIAGE', 'AGE', 'PAY_0',
           'PAY_2', 'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2',
           'BILL_AMT3', 'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1',
           'PAY_AMT2', 'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month'],
          dtype='object')




```python
pii_features=['SEX', 'EDUCATION', 'MARRIAGE', 'AGE']
for i in pii_features:
    print(i,' -> ', raw_data[i].unique())
```

    SEX  ->  [2 1]
    EDUCATION  ->  [0 1]
    MARRIAGE  ->  [1 2 3 0]
    AGE  ->  [24 26 34 37 57 29 23 28 35 51 41 30 49 39 40 27 47 33 32 54 58 22 25 31
     46 42 43 45 56 44 53 38 63 36 52 48 55 60 50 75 61 73 59 21 67 66 62 70
     72 64 65 71 69 68 79 74]



```python
bin_edges = [21, 41, 61, 81]

# Create the bins
raw_data['age_bins'] = pd.cut(raw_data['AGE'], bin_edges)
raw_data['age_bins'].unique()

```




    [(21.0, 41.0], (41.0, 61.0], (61.0, 81.0], NaN]
    Categories (3, interval[int64, right]): [(21, 41] < (41, 61] < (61, 81]]




```python
raw_data = raw_data.drop('AGE', axis=1)
```


```python
raw_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'MARRIAGE', 'PAY_0', 'PAY_2',
           'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2',
           'BILL_AMT3', 'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1',
           'PAY_AMT2', 'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'age_bins'],
          dtype='object')




```python
def oneHotEnc(df,col_name):
    one_hot = pd.get_dummies(df[col_name], prefix=col_name)
    df = df.drop(col_name, axis=1)
    df = df.join(one_hot)
    return df
```


```python
cols=['MARRIAGE', 'age_bins']
for i in cols:
    raw_data=oneHotEnc(raw_data,i)
raw_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>PAY_5</th>
      <th>PAY_6</th>
      <th>...</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
      <th>MARRIAGE_0</th>
      <th>MARRIAGE_1</th>
      <th>MARRIAGE_2</th>
      <th>MARRIAGE_3</th>
      <th>age_bins_(21, 41]</th>
      <th>age_bins_(41, 61]</th>
      <th>age_bins_(61, 81]</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>20000</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>120000</td>
      <td>2</td>
      <td>0</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>...</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>90000</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>50000</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>50000</td>
      <td>1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29995</th>
      <td>29996</td>
      <td>220000</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>5000</td>
      <td>1000</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29996</th>
      <td>29997</td>
      <td>150000</td>
      <td>1</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29997</th>
      <td>29998</td>
      <td>30000</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2000</td>
      <td>3100</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29998</th>
      <td>29999</td>
      <td>80000</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>...</td>
      <td>52964</td>
      <td>1804</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29999</th>
      <td>30000</td>
      <td>50000</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1000</td>
      <td>1000</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>30000 rows × 30 columns</p>
</div>




```python
raw_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]'],
          dtype='object')



## Normalised Statistical Parity Difference and Disparate Impact for comparison for data bias


```python
cols=['SEX', 'EDUCATION','MARRIAGE_0', 'MARRIAGE_1','MARRIAGE_2', 'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
       'age_bins_(61, 81]']
```


```python
def heatmap_protected(df,i):

    pivot=df.reset_index().pivot_table(index=i, columns='default payment next month', aggfunc='count')
#     print(pivot)
    ax = sns.heatmap(pivot, annot=True,fmt='g')
    plt.show()
    return pivot

```


```python
for i in cols:
    print(heatmap_protected(raw_data[[i,'default payment next month']],i))
```


    
![png](output_31_0.png)
    


                                index      
    default payment next month      0     1
    SEX                                    
    1                            9015  2873
    2                           14349  3763



    
![png](output_31_2.png)
    


                                index      
    default payment next month      0     1
    EDUCATION                              
    0                           22943  6603
    1                             421    33



    
![png](output_31_4.png)
    


                                index      
    default payment next month      0     1
    MARRIAGE_0                             
    0                           23315  6631
    1                              49     5



    
![png](output_31_6.png)
    


                                index      
    default payment next month      0     1
    MARRIAGE_1                             
    0                           12911  3430
    1                           10453  3206



    
![png](output_31_8.png)
    


                                index      
    default payment next month      0     1
    MARRIAGE_2                             
    0                           10741  3295
    1                           12623  3341



    
![png](output_31_10.png)
    


                                index      
    default payment next month      0     1
    MARRIAGE_3                             
    0                           23125  6552
    1                             239    84



    
![png](output_31_12.png)
    


                                index      
    default payment next month      0     1
    age_bins_(21, 41]                      
    0                            5712  1805
    1                           17652  4831



    
![png](output_31_14.png)
    


                                index      
    default payment next month      0     1
    age_bins_(41, 61]                      
    0                           17869  4897
    1                            5495  1739



    
![png](output_31_16.png)
    


                                index      
    default payment next month      0     1
    age_bins_(61, 81]                      
    0                           23200  6584
    1                             164    52



```python
statistical_parity=[]
disparate_impact=[]

def statistical_parity_test(df,protected_group,Sa_label,Sd_label,y,fav_label):
    Sa=df[raw_data[protected_group] == Sa_label]
    fav_Sa=Sa[Sa[y] == fav_label]
    fav_Sa_count = len(fav_Sa)
    Sd=df[raw_data[protected_group] == Sd_label]
    fav_Sd=Sd[Sd[y] == fav_label]
    fav_Sd_count = len(fav_Sd)
    adv=len(Sa)
    disadv=len(Sd)
    statistical_parity.append((fav_Sd_count/disadv)-(fav_Sa_count/adv))
    disparate_impact.append((fav_Sd_count/disadv)/(fav_Sa_count/adv))
    
    
```


```python

statistical_parity_test(raw_data,'SEX',2,1,'default payment next month',0)
statistical_parity_test(raw_data,'EDUCATION',0,1,'default payment next month',0)
statistical_parity_test(raw_data,'MARRIAGE_0',0,1,'default payment next month',0)
statistical_parity_test(raw_data,'MARRIAGE_1',0,1,'default payment next month',0)
statistical_parity_test(raw_data,'MARRIAGE_2',1,0,'default payment next month',0)
statistical_parity_test(raw_data,'MARRIAGE_3',0,1,'default payment next month',0)
statistical_parity_test(raw_data,'age_bins_(21, 41]',1,0,'default payment next month',0)
statistical_parity_test(raw_data,'age_bins_(41, 61]',0,1,'default payment next month',0)
statistical_parity_test(raw_data,'age_bins_(61, 81]',0,1,'default payment next month',0)


```


```python
def plot_SPD_DI(cols,statistical_parity,disparate_impact):
    d = pd.DataFrame({'Protected_feature':cols,'Statistical_Parity':statistical_parity,'Disparate_Impact':disparate_impact})
    d['DI_normal']=d["Disparate_Impact"].apply(lambda x: 1/x if x < 1 else x)
    d['SP_normal']=d["Statistical_Parity"].apply(lambda x: abs(x) if x < 0 else x)

    fig = plt.figure() 
    ax = fig.add_subplot(111) 
    ax2 = ax.twinx() # Create another axes that shares the same x-axis as ax.

    fig.suptitle('Normalised Statistical Parity Difference and Disparate Impact for comparison', fontsize=40, y=1)

    width = 0.3
    ax.set_ylim(0, 0.25) 
    ax2.set_ylim(0, 1.5) 

    d.plot(x ='Protected_feature', y='SP_normal', kind = 'bar', ax=ax, width=width, 
           position=1, color='green', legend=False, figsize=(30,10), fontsize=20)
    d.plot(x ='Protected_feature', y='DI_normal', kind = 'bar', ax=ax2, width=width, 
           position=0, color='black', legend=False, figsize=(30,10), fontsize=20)

    ax.axhline(y=0.10, linestyle='dashed', linewidth=2, alpha=0.7, color='green')
    ax2.axhline(y=0.80, linestyle='dashed', linewidth=2, alpha=0.7, color='black')

    patches, labels = ax.get_legend_handles_labels()
    ax.legend(patches, ['Stat Parity Diff'], loc='upper left', fontsize=25)

    patches, labels = ax2.get_legend_handles_labels()
    ax2.legend(patches, ['Disparate Impact'], loc='upper right', fontsize=25)

    labels = [item.get_text() for item in ax.get_xticklabels()]

    ax.set_xticklabels(labels)
    ax.set_xlabel('Protected Groups', fontsize=25)
    ax.set_ylabel('Statistical Parity Difference', fontsize=25)
    ax2.set_ylabel('Disparate Impact', fontsize=25)

    plt.show()
```


```python
plot_SPD_DI(cols,statistical_parity,disparate_impact)
```


    
![png](output_35_0.png)
    



```python
cols.append('Combined_protected_group')
```


```python
raw_data['Combined_protected_group'] = np.where((raw_data['MARRIAGE_0'] == 0) & (raw_data['EDUCATION'] == 0),0, 1)

choice = 'Combined_protected_group'#'Combined_protected_group' #'NrOfDependantslessthan3'
pval = 1
upval = 0
```


```python
plt.subplots(figsize=(10,5))
plotdf=pd.crosstab(raw_data[choice], raw_data['default payment next month'])
ax=sns.heatmap(plotdf, annot=True, fmt='g', cbar=False, annot_kws={'size':20})    #axes.plot(vc)
plt.xlabel('default payment next month', fontsize=18)
plt.ylabel('Composite Feature', fontsize=16)

plt.show()    #axes.plot(vc)

```


    
![png](output_38_0.png)
    



```python
statistical_parity_test(raw_data,'Combined_protected_group',0,1,'default payment next month',0)
```


```python
plot_SPD_DI(cols,statistical_parity,disparate_impact)
```


    
![png](output_40_0.png)
    



```python
# reweighing on combine feature
```


```python
def Reweighing1 (data, choice, target_feature, pval, upval, fav=0, unfav=1):


    dummy = np.repeat(1, len(data)) 
    data['dummy'] = dummy

    n = np.sum(data['dummy']) #Total number of instances
    sa = np.sum(data['dummy'][data[choice]==pval]) #Total number of privileged
    sd = np.sum(data['dummy'][data[choice]==upval]) #Total number of unprivileged
    ypos = np.sum(data['dummy'][data[target_feature]==fav]) #Total number of favourable
    yneg = np.sum(data['dummy'][data[target_feature]==unfav]) #Total number of unfavourable
    
    data_sa_ypos = data[(data[choice]==pval) & (data[target_feature]==fav)] # priviliged and favourable
    data_sa_yneg = data[(data[choice]==pval) & (data[target_feature]==unfav)] # priviliged and unfavourable
    data_sd_ypos = data[(data[choice]==upval) & (data[target_feature]==fav)] # unpriviliged and favourable
    data_sd_yneg = data[(data[choice]==upval) & (data[target_feature]==unfav)] # unpriviliged and unfavourable

    sa_ypos = np.sum(data_sa_ypos['dummy']) #Total number of privileged and favourable
    sa_yneg = np.sum(data_sa_yneg['dummy']) #Total number of privileged and unfavourable
    sd_ypos = np.sum(data_sd_ypos['dummy']) #Total number of unprivileged and favourable
    sd_yneg = np.sum(data_sd_yneg['dummy']) #Total number of unprivileged and unfavourable

    w_sa_ypos= (ypos*sa) / (n*sa_ypos) #weight for privileged and favourable
    w_sa_yneg = (yneg*sa) / (n*sa_yneg) #weight for privileged and unfavourable
    w_sd_ypos = (ypos*sd) / (n*sd_ypos) #weight for unprivileged and favourable
    w_sd_yneg = (yneg*sd) / (n*sd_yneg) #weight for unprivileged and unfavourable

    datatest=data #.copy()
    
#     print (w_sa_ypos, w_sa_yneg, w_sd_ypos, w_sd_yneg)
    
    DiscriminationBefore=(sa_ypos/sa)-(sd_ypos/sd)
    DiscriminationAfter=(sa_ypos/sa * w_sa_ypos)-(sd_ypos/sd * w_sd_ypos)


    print ("DiscriminationBefore: {} \nDiscriminationAfter: {}  ".format(DiscriminationBefore, DiscriminationAfter))
    
    datatest['NewWeights']= np.repeat(999, len(datatest)) 
    datatest.loc[(datatest[choice]==pval) & (datatest[target_feature]==fav), 'NewWeights'] = w_sa_ypos
    datatest.loc[(datatest[choice]==pval) & (datatest[target_feature]==unfav), 'NewWeights'] = w_sa_yneg
    datatest.loc[(datatest[choice]==upval) & (datatest[target_feature]==fav), 'NewWeights'] = w_sd_ypos
    datatest.loc[(datatest[choice]==upval) & (datatest[target_feature]==unfav), 'NewWeights'] = w_sd_yneg

    return datatest['NewWeights']
```


```python
weighted_data = raw_data.copy(deep =True)
```


```python
weighted_data['Weights']=Reweighing1(raw_data,'Combined_protected_group','default payment next month',0,1,0,1)
```

    DiscriminationBefore: -0.14891853763091767 
    DiscriminationAfter: 0.0  


### Differential privacy on protected variable


```python
dp_limit_bal = raw_data.copy(deep =True)
dp_limit_bal_with_weight = weighted_data.copy(deep=True)
```


```python
epsilon =0.5
sensitivity=1
dp_LIMIT_BAL=[]
dp_LIMIT_BAL_weight=[]
original_weighted=weighted_data['LIMIT_BAL']
original = raw_data['LIMIT_BAL']

for i in range(0,30000):
        value=original[i] +  np.random.laplace(loc=0, scale=sensitivity/epsilon)
        value = round(value)
        dp_LIMIT_BAL.append(value)
        value1=original_weighted[i] +  np.random.laplace(loc=0, scale=sensitivity/epsilon)
        value1 = round(value1)
        dp_LIMIT_BAL_weight.append(value1)
dp_limit_bal['LIMIT_BAL']=dp_LIMIT_BAL
dp_limit_bal_with_weight['LIMIT_BAL']=dp_LIMIT_BAL_weight
```

## 4 Datasets


```python
raw_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]', 'Combined_protected_group', 'dummy', 'NewWeights'],
          dtype='object')




```python
raw_data.drop(columns=['dummy', 'NewWeights',
       'Combined_protected_group'],inplace=True)
```


```python
raw_data.describe()['LIMIT_BAL']
```




    count      30000.000000
    mean      167484.322667
    std       129747.661567
    min        10000.000000
    25%        50000.000000
    50%       140000.000000
    75%       240000.000000
    max      1000000.000000
    Name: LIMIT_BAL, dtype: float64




```python
dp_limit_bal.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]', 'Combined_protected_group', 'dummy', 'NewWeights'],
          dtype='object')




```python
dp_limit_bal.drop(columns=['dummy', 'NewWeights',
       'Combined_protected_group'],inplace=True)
```


```python
dp_limit_bal.describe()['LIMIT_BAL'].apply(lambda x: format(x, 'f'))
```




    count      30000.000000
    mean      167484.308167
    std       129747.685374
    min         9986.000000
    25%        50005.000000
    50%       140000.000000
    75%       239999.000000
    max      1000000.000000
    Name: LIMIT_BAL, dtype: object




```python
weighted_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]', 'Combined_protected_group', 'Weights'],
          dtype='object')




```python
weighted_data.drop(columns=[
       'Combined_protected_group'],inplace=True)
```


```python
weighted_data.describe()['LIMIT_BAL']
```




    count      30000.000000
    mean      167484.322667
    std       129747.661567
    min        10000.000000
    25%        50000.000000
    50%       140000.000000
    75%       240000.000000
    max      1000000.000000
    Name: LIMIT_BAL, dtype: float64




```python
dp_limit_bal_with_weight.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]', 'Combined_protected_group', 'Weights'],
          dtype='object')




```python
dp_limit_bal_with_weight.drop(columns=[
       'Combined_protected_group'],inplace=True)
```


```python
dp_limit_bal_with_weight.describe()['LIMIT_BAL'].apply(lambda x: format(x, 'f'))
```




    count     30000.000000
    mean     167484.333967
    std      129747.645315
    min        9989.000000
    25%       50005.000000
    50%      140001.000000
    75%      239999.000000
    max      999996.000000
    Name: LIMIT_BAL, dtype: object




```python
cols.remove('Combined_protected_group')
```

## Model


```python
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import average_precision_score
from sklearn.metrics import mean_squared_error
```


```python
def split_data(df):
    x=df.drop("default payment next month", axis=1)

    y=df[['default payment next month']]
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.30, random_state=6666)
    return X_train, X_test, y_train, y_test
    
```


```python
def Accuracy_difference(X_test,y_test,model_name,model):
    y_pred_wow=model.predict(X_test)
    y_pred_prob_wow=model.predict_proba(X_test)[:,0]
    print("Accuracy of the model {} without weights:{}".format(model_name,model.score(X_test, y_test)))
    
    for i in cols:
        A_wow=model.score(X_test[X_test[i]==X_test[i].unique()[0]], y_test[X_test[i]==X_test[i].unique()[0]])
        B_wow=model.score(X_test[X_test[i]==X_test[i].unique()[1]], y_test[X_test[i]==X_test[i].unique()[1]])
        print("Accuracy difference between two groups {} :{}{} ".format(i,abs(B_wow-A_wow)*100 ,"%"))
    return y_pred_wow,y_pred_prob_wow
```

### Raw data on Random forest


```python
X_train, X_test, y_train, y_test = split_data(raw_data)

clf = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)

y_pred_raw_random,y_pred_prob_raw_random=Accuracy_difference(X_test,y_test,'Random Forest on raw data',clf)
```

    Accuracy of the model Random Forest on raw data without weights:0.8181111111111111
    Accuracy difference between two groups SEX :1.8416844349680161% 
    Accuracy difference between two groups EDUCATION :6.563486248872863% 
    Accuracy difference between two groups MARRIAGE_0 :4.895104895104896% 
    Accuracy difference between two groups MARRIAGE_1 :1.577158605002038% 
    Accuracy difference between two groups MARRIAGE_2 :2.090018870241972% 
    Accuracy difference between two groups MARRIAGE_3 :11.227543381233973% 
    Accuracy difference between two groups age_bins_(21, 41] :0.30424531843642466% 
    Accuracy difference between two groups age_bins_(41, 61] :0.28918599568471537% 
    Accuracy difference between two groups age_bins_(61, 81] :1.1740376356116355% 


## DP Data on random forest


```python
X_train, X_test, y_train, y_test = split_data(dp_limit_bal)

clf_dp = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)

y_pred_raw_dp_rand,y_pred_prob_raw_dp_rand=Accuracy_difference(X_test,y_test,'Random Forest on dp data',clf_dp)
```

    Accuracy of the model Random Forest on dp data without weights:0.8157777777777778
    Accuracy difference between two groups SEX :1.9573150729867095% 
    Accuracy difference between two groups EDUCATION :5.215143146979262% 
    Accuracy difference between two groups MARRIAGE_0 :4.66143403719903% 
    Accuracy difference between two groups MARRIAGE_1 :1.6891147956332397% 
    Accuracy difference between two groups MARRIAGE_2 :2.145178039058049% 
    Accuracy difference between two groups MARRIAGE_3 :9.970279131047588% 
    Accuracy difference between two groups age_bins_(21, 41] :0.10752203751257516% 
    Accuracy difference between two groups age_bins_(41, 61] :0.26749465106494785% 
    Accuracy difference between two groups age_bins_(61, 81] :0.6850056662744852% 


## Weighted on random


```python
X_train, X_test, y_train, y_test =split_data(weighted_data)
X_train_weights=X_train['Weights']
X_test_weights=X_test['Weights']

X_train1=X_train.drop(columns=["Weights"])
X_test1=X_test.drop(columns=["Weights"])
```


```python
clf_weighted_1 =RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train1, y_train , sample_weight=X_train_weights)

y_pred_weight_rand,y_pred_prob_weight_rand=Accuracy_difference(X_test1,y_test,'Random Forest on wegihted data',clf_weighted_1)
```

    Accuracy of the model Random Forest on wegihted data without weights:0.8181111111111111
    Accuracy difference between two groups SEX :1.7494259471871443% 
    Accuracy difference between two groups EDUCATION :4.185922001803421% 
    Accuracy difference between two groups MARRIAGE_0 :4.895104895104896% 
    Accuracy difference between two groups MARRIAGE_1 :1.1735243217810387% 
    Accuracy difference between two groups MARRIAGE_2 :1.732712513538559% 
    Accuracy difference between two groups MARRIAGE_3 :12.248879084066132% 
    Accuracy difference between two groups age_bins_(21, 41] :0.2363682779955245% 
    Accuracy difference between two groups age_bins_(41, 61] :0.2034880776979775% 
    Accuracy difference between two groups age_bins_(61, 81] :2.798129046694431% 



```python
X_train, X_test, y_train, y_test =split_data(dp_limit_bal_with_weight)
X_train_weights=X_train['Weights']
X_test_weights=X_test['Weights']

X_train1=X_train.drop(columns=["Weights"])
X_test1=X_test.drop(columns=["Weights"])
```

 ## Weighted DP data on random forest


```python
clf_weighted_1 =RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train1, y_train , sample_weight=X_train_weights)

y_pred_weight_dp_rand,y_pred_prob_weight_dp_rand=Accuracy_difference(X_test1,y_test,'Random Forest on wegihted DP data',clf_weighted_1)
```

    Accuracy of the model Random Forest on wegihted DP data without weights:0.8185555555555556
    Accuracy difference between two groups SEX :1.6395358372970348% 
    Accuracy difference between two groups EDUCATION :5.725879170423809% 
    Accuracy difference between two groups MARRIAGE_0 :4.939613629944106% 
    Accuracy difference between two groups MARRIAGE_1 :0.940771851402189% 
    Accuracy difference between two groups MARRIAGE_2 :1.5478064739445463% 
    Accuracy difference between two groups MARRIAGE_3 :13.315153557822923% 
    Accuracy difference between two groups age_bins_(21, 41] :0.05496238230391359% 
    Accuracy difference between two groups age_bins_(41, 61] :0.04624293594334139% 
    Accuracy difference between two groups age_bins_(61, 81] :4.466973198882629% 



```python

def gini(actual, pred):
    """

    :param actual: actual values
    :param pred: predicted probablities
    :return: gini scores
    """
    assert (len(actual) == len(pred))
    all = np.asarray(np.c_[actual, pred, np.arange(len(actual))], dtype=np.float)
    all = all[np.lexsort((all[:, 2], -1 * all[:, 1]))]
    totalLosses = all[:, 0].sum()
    giniSum = all[:, 0].cumsum().sum() / totalLosses

    giniSum -= (len(actual) + 1) / 2.
    return giniSum / len(actual)
```


```python
def gini_normalized(actual, pred):
    """

    :param actual: actual values
    :param pred: predicted probablities
    :return: normalized gini scores
    """
    return gini(actual, pred) / gini(actual, actual)
```


```python
def model_perff(y_test, y_pred_prob_ww, y_pred_prob_wow, y_pred_ww, y_pred_wow, X_test1):
    
    model_perf=[model_metrics(y_test, y_pred_prob_ww, y_pred_prob_wow, 
                              y_pred_ww, y_pred_wow, X_test1)]

    headers=["AUC", "Gini", "Avg Precision Score", "Precision", "Sensitivity", "False Negative Rate", 
             "F1 Score", "Total Cost"]


    #full_metric={'With Weights':B, 
    #             'Without_Weights':list(ww[0]), 'Without_Weights':list(wow[0])}

    #compare_table=pd.DataFrame.from_dict(ww_wow)

    B = list(model_perf[0])[:len(list(model_perf[0]))//2]
    C = list(model_perf[0])[len(list(model_perf[0]))//2:]


    model_table={'Metrics':headers, 
                 'With_Weights':B, 'Without_Weights':C}

    model_table_df=pd.DataFrame.from_dict(model_table)
    model_table_df.loc[8] = ['Total Cost (in Mn)', model_table_df.iloc[7,1]/10000000, model_table_df.iloc[7,2]/10000000]
    return model_table_df
```


```python
model_table_df_random_forest=model_perff(y_test,y_pred_prob_weight_rand,y_pred_prob_raw_random,y_pred_weight_rand,y_pred_raw_random,X_test1)
```


```python
#plt.clf()
#plt.figure()
#Married, singlr, divorced
def plot_reweigh(model_table_df):
    txt='Composite feature'

    ax = model_table_df.iloc[[0,2,3,4,5,6,8],:].plot.bar(x='Metrics', rot=90, width = 0.7, 
                                                           color=['red', 'black'], figsize=(10,5), fontsize=12)
    plt.suptitle('Before and after reweighting: {}'.format(txt),  fontsize=16, y=1)



    patches, labels = ax.get_legend_handles_labels()
    ax.legend(patches, labels, loc='upper right', fontsize=12)

    ax.set_xlabel('Accuracy metrics', fontsize=15)


    #plt.savefig('BnAR.svg', format='svg', dpi=500, bbox_inches='tight') #,
    #plt.savefig('BnAR.png', format='png', dpi=500, bbox_inches='tight')
    #beingsaved = plt.figure()
    #beingsaved.savefig('BnAR.eps', format='eps', dpi=500)

    plt.show()
```


```python
plot_reweigh(model_table_df_random_forest)
```


    
![png](output_81_0.png)
    


### ACF


```python
raw_data.columns
```




    Index(['ID', 'LIMIT_BAL', 'SEX', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
           'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
           'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
           'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month', 'MARRIAGE_0', 'MARRIAGE_1', 'MARRIAGE_2',
           'MARRIAGE_3', 'age_bins_(21, 41]', 'age_bins_(41, 61]',
           'age_bins_(61, 81]'],
          dtype='object')




```python
def data_acf(df)  :
    dataacf = df[['ID', 'LIMIT_BAL', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
       'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
       'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
       'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
       'default payment next month', 'MARRIAGE_0']]
    return dataacf
biased_protected_groups = ['EDUCATION','MARRIAGE_0']
```


```python
dataacf=data_acf(raw_data)
```


```python
dataacf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>EDUCATION</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>PAY_5</th>
      <th>PAY_6</th>
      <th>BILL_AMT1</th>
      <th>...</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
      <th>MARRIAGE_0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>20000</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>-2</td>
      <td>-2</td>
      <td>3913</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>120000</td>
      <td>0</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2682</td>
      <td>...</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>90000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>29239</td>
      <td>...</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>50000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>46990</td>
      <td>...</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>50000</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8617</td>
      <td>...</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29995</th>
      <td>29996</td>
      <td>220000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>188948</td>
      <td>...</td>
      <td>31237</td>
      <td>15980</td>
      <td>8500</td>
      <td>20000</td>
      <td>5003</td>
      <td>3047</td>
      <td>5000</td>
      <td>1000</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29996</th>
      <td>29997</td>
      <td>150000</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>1683</td>
      <td>...</td>
      <td>5190</td>
      <td>0</td>
      <td>1837</td>
      <td>3526</td>
      <td>8998</td>
      <td>129</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29997</th>
      <td>29998</td>
      <td>30000</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>3565</td>
      <td>...</td>
      <td>20582</td>
      <td>19357</td>
      <td>0</td>
      <td>0</td>
      <td>22000</td>
      <td>4200</td>
      <td>2000</td>
      <td>3100</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29998</th>
      <td>29999</td>
      <td>80000</td>
      <td>0</td>
      <td>1</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>-1645</td>
      <td>...</td>
      <td>11855</td>
      <td>48944</td>
      <td>85900</td>
      <td>3409</td>
      <td>1178</td>
      <td>1926</td>
      <td>52964</td>
      <td>1804</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29999</th>
      <td>30000</td>
      <td>50000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>47929</td>
      <td>...</td>
      <td>32428</td>
      <td>15313</td>
      <td>2078</td>
      <td>1800</td>
      <td>1430</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>30000 rows × 23 columns</p>
</div>




```python
dataacf_dp=data_acf(dp_limit_bal)
```

## ACF on raw data


```python
X_train, X_test, y_train, y_test =split_data(dataacf)
```


```python
log_reg = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)
```


```python
y_pred=log_reg.predict(X_test)
y_pred_prob=log_reg.predict_proba(X_test)[:,0]
print("Accuracy of the baseline model:", log_reg.score(X_test, y_test))
```

    Accuracy of the baseline model: 0.8163333333333334



```python
def metrics(choices):
    for choice in choices:
        
        A_full=log_reg.score(X_test[X_test[choice]==0], y_test[X_test[choice]==0]) 
        B_full=log_reg.score(X_test[X_test[choice]==1], y_test[X_test[choice]==1]) 
        print("Accuracy difference between two groups:", abs(B_full-A_full)*100, "%")
```


```python
metrics(biased_protected_groups)
```

    Accuracy difference between two groups: 5.158786068530208 %
    Accuracy difference between two groups: 4.717069955748043 %



```python
sens=X_train[biased_protected_groups]
```


```python
from sklearn.linear_model import LinearRegression
```


```python
acf_LIMIT_BAL = RandomForestClassifier().fit(sens, X_train['LIMIT_BAL'])
acf_PAY_0 =RandomForestClassifier().fit(sens, X_train['PAY_0'])
acf_PAY_2 = RandomForestClassifier().fit(sens, X_train['PAY_2'])
acf_PAY_3 = RandomForestClassifier().fit(sens, X_train['PAY_3'])
acf_PAY_4 = RandomForestClassifier().fit(sens, X_train['PAY_4'])
acf_IPAY_5 = RandomForestClassifier().fit(sens, X_train['PAY_5'])
acf_PAY_6 = RandomForestClassifier().fit(sens, X_train['PAY_6'])
acf_BILL_AMT1 = RandomForestClassifier().fit(sens, X_train['BILL_AMT1'])
acf_BILL_AMT2 = RandomForestClassifier().fit(sens, X_train['BILL_AMT2'])
acf_BILL_AMT3 = RandomForestClassifier().fit(sens, X_train['BILL_AMT3'])
acf_BILL_AMT4 = RandomForestClassifier().fit(sens, X_train['BILL_AMT4'])
acf_BILL_AMT5 = RandomForestClassifier().fit(sens, X_train['BILL_AMT5'])
acf_BILL_AMT6 = RandomForestClassifier().fit(sens, X_train['BILL_AMT6'])
acf_PAY_AMT1 = RandomForestClassifier().fit(sens, X_train['PAY_AMT1'])
acf_PAY_AMT2 = RandomForestClassifier().fit(sens, X_train['PAY_AMT2'])
acf_PAY_AMT3 = RandomForestClassifier().fit(sens, X_train['PAY_AMT3'])
acf_PAY_AMT4 = RandomForestClassifier().fit(sens, X_train['PAY_AMT4'])
acf_PAY_AMT5 = RandomForestClassifier().fit(sens, X_train['PAY_AMT5'])
acf_PAY_AMT6 = RandomForestClassifier().fit(sens, X_train['PAY_AMT6'])
```


```python
sens_test=X_test[biased_protected_groups]
```


```python
limit_balR =  X_train['LIMIT_BAL'] - acf_LIMIT_BAL.predict(sens)
acf_PAY_0R =X_train['PAY_0'] - acf_PAY_0.predict(sens)
acf_PAY_2R = X_train['PAY_2'] - acf_PAY_2.predict(sens)
acf_PAY_3R = X_train['PAY_3'] - acf_PAY_3.predict(sens)
acf_PAY_4R = X_train['PAY_4'] - acf_PAY_4.predict(sens)
acf_IPAY_5R = X_train['PAY_5'] - acf_IPAY_5.predict(sens)
acf_BILL_AMT1R = X_train['BILL_AMT1'] - acf_BILL_AMT1.predict(sens)
acf_BILL_AMT2R = X_train['BILL_AMT2'] - acf_BILL_AMT2.predict(sens)
acf_BILL_AMT3R = X_train['BILL_AMT3'] - acf_BILL_AMT3.predict(sens)
acf_BILL_AMT4R = X_train['BILL_AMT4'] - acf_BILL_AMT4.predict(sens)
acf_BILL_AMT5R = X_train['BILL_AMT5'] - acf_BILL_AMT5.predict(sens)
acf_BILL_AMT6R = X_train['BILL_AMT6'] - acf_BILL_AMT6.predict(sens)
acf_PAY_AMT1R = X_train['PAY_AMT1'] - acf_PAY_AMT1.predict(sens)
acf_PAY_AMT2R = X_train['PAY_AMT2'] - acf_PAY_AMT2.predict(sens)
acf_PAY_AMT3R = X_train['PAY_AMT3'] - acf_PAY_AMT3.predict(sens)
acf_PAY_AMT4R = X_train['PAY_AMT4'] - acf_PAY_AMT4.predict(sens)
acf_PAY_AMT5R = X_train['PAY_AMT5'] - acf_PAY_AMT5.predict(sens)
acf_PAY_AMT6R = X_train['PAY_AMT6'] - acf_PAY_AMT6.predict(sens)
```


```python
df_R=pd.DataFrame({'limit_balR':limit_balR, 'acf_PAY_0R':acf_PAY_0R, 'acf_PAY_2R':acf_PAY_2R, 
                   'acf_PAY_3R':acf_PAY_3R,
                'acf_PAY_4R':acf_PAY_4R, 'acf_IPAY_5R':acf_IPAY_5R, 'acf_BILL_AMT1R':acf_BILL_AMT1R,
                   'acf_BILL_AMT2R':acf_BILL_AMT2R,'acf_BILL_AMT3R':acf_BILL_AMT3R,'acf_BILL_AMT4R':acf_BILL_AMT4R,
                  'acf_BILL_AMT5R':acf_BILL_AMT5R,'acf_BILL_AMT6R':acf_BILL_AMT6R, 'acf_PAY_AMT1R':acf_PAY_AMT1R,'acf_PAY_AMT2R':acf_PAY_AMT2R,
                  'acf_PAY_AMT3R':acf_PAY_AMT3R,'acf_PAY_AMT4R':acf_PAY_AMT4R,'acf_PAY_AMT5R':acf_PAY_AMT5R,'acf_PAY_AMT6R':acf_PAY_AMT6R})
```


```python
fair = RandomForestClassifier(n_estimators=100, random_state=42).fit(df_R, y_train)
```


```python
sens_test=X_test[biased_protected_groups]
```


```python
limit_balR =  X_test['LIMIT_BAL'] - acf_LIMIT_BAL.predict(sens_test)
acf_PAY_0R =X_test['PAY_0'] - acf_PAY_0.predict(sens_test)
acf_PAY_2R = X_test['PAY_2'] - acf_PAY_2.predict(sens_test)
acf_PAY_3R = X_test['PAY_3'] - acf_PAY_3.predict(sens_test)
acf_PAY_4R = X_test['PAY_4'] - acf_PAY_4.predict(sens_test)
acf_IPAY_5R = X_test['PAY_5'] - acf_IPAY_5.predict(sens_test)
acf_BILL_AMT1R = X_test['BILL_AMT1'] - acf_BILL_AMT1.predict(sens_test)
acf_BILL_AMT2R = X_test['BILL_AMT2'] - acf_BILL_AMT2.predict(sens_test)
acf_BILL_AMT3R = X_test['BILL_AMT3'] - acf_BILL_AMT3.predict(sens_test)
acf_BILL_AMT4R = X_test['BILL_AMT4'] - acf_BILL_AMT4.predict(sens_test)
acf_BILL_AMT5R = X_test['BILL_AMT5'] - acf_BILL_AMT5.predict(sens_test)
acf_BILL_AMT6R = X_test['BILL_AMT6'] - acf_BILL_AMT6.predict(sens_test)
acf_PAY_AMT1R = X_test['PAY_AMT1'] - acf_PAY_AMT1.predict(sens_test)
acf_PAY_AMT2R = X_test['PAY_AMT2'] - acf_PAY_AMT2.predict(sens_test)
acf_PAY_AMT3R = X_test['PAY_AMT3'] - acf_PAY_AMT3.predict(sens_test)
acf_PAY_AMT4R = X_test['PAY_AMT4'] - acf_PAY_AMT4.predict(sens_test)
acf_PAY_AMT5R = X_test['PAY_AMT5'] - acf_PAY_AMT5.predict(sens_test)
acf_PAY_AMT6R = X_test['PAY_AMT6'] - acf_PAY_AMT6.predict(sens_test)
```


```python
df_R_test=pd.DataFrame({'limit_balR':limit_balR, 'acf_PAY_0R':acf_PAY_0R, 'acf_PAY_2R':acf_PAY_2R, 
                   'acf_PAY_3R':acf_PAY_3R,
                'acf_PAY_4R':acf_PAY_4R, 'acf_IPAY_5R':acf_IPAY_5R, 'acf_BILL_AMT1R':acf_BILL_AMT1R,
                   'acf_BILL_AMT2R':acf_BILL_AMT2R,'acf_BILL_AMT3R':acf_BILL_AMT3R,'acf_BILL_AMT4R':acf_BILL_AMT4R,
                  'acf_BILL_AMT5R':acf_BILL_AMT5R,'acf_BILL_AMT6R':acf_BILL_AMT6R, 'acf_PAY_AMT1R':acf_PAY_AMT1R,'acf_PAY_AMT2R':acf_PAY_AMT2R,
                  'acf_PAY_AMT3R':acf_PAY_AMT3R,'acf_PAY_AMT4R':acf_PAY_AMT4R,'acf_PAY_AMT5R':acf_PAY_AMT5R,'acf_PAY_AMT6R':acf_PAY_AMT6R})
```


```python
y_pred_fair = fair.predict(df_R_test)
y_pred_prob_fair = fair.predict_proba(df_R_test)
```


```python
print("Accuracy of the fair model:", fair.score(df_R_test, y_test))
```

    Accuracy of the fair model: 0.814



```python
logistic_reg_fair_metrics=[]
for choice in biased_protected_groups:
    logistic_reg_fair_metrics.append(fair_metrics(y_test, y_pred_prob, y_pred, X_test, choice, 0, 1))
    
```


```python
acf_metrics=[]
for choice in biased_protected_groups:
    tn_disadv, fp_disadv, fn_disadv, tp_disadv = confusion_matrix(y_test[sens_test[choice]==1], y_pred_fair[sens_test[choice]==1]).ravel()
    tn_adv, fp_adv, fn_adv, tp_adv = confusion_matrix(y_test[sens_test[choice]==0], y_pred_fair[sens_test[choice]==0]).ravel()

    acf_metrics.append(acf_fair_metrics(tn_disadv, fp_disadv, fn_disadv, tp_disadv, tn_adv, fp_adv, fn_adv, tp_adv))

    
```


```python
    
for i in range(0,2):
    labels, log_reg_model = zip(*logistic_reg_fair_metrics[i])
    headers, acf_model = zip(*acf_metrics[i])
    ACF={'Metrics':headers, 
                 'Baseline Model':list(log_reg_model), 'ACF Fair Model':list(acf_model)}
    ACF_table=pd.DataFrame.from_dict(ACF)
    print("Education" if i == 0 else "MARRIAGE_0")
    print(ACF_table)
    print("\n")
    ax = ACF_table.plot.bar(x='Metrics', rot=90, width = 0.7, color=['black', 'green'], figsize=(10,5), fontsize=12)
    
plt.show()
```

    Education
          Metrics  Baseline Model  ACF Fair Model
    0  Equal Opps        0.275033        0.271927
    1      PredEq        0.000607        0.010245
    2  Equal Odds        0.274426        0.282173
    3  DemoParity        0.063514        0.072454
    4         AOD        0.137213        0.141086
    
    
    MARRIAGE_0
          Metrics  Baseline Model  ACF Fair Model
    0  Equal Opps        0.364760        0.361669
    1      PredEq        0.031727        0.029598
    2  Equal Odds        0.333034        0.332072
    3  DemoParity        0.048258        0.049259
    4         AOD        0.166517        0.166036
    
    



    
![png](output_108_1.png)
    



    
![png](output_108_2.png)
    



```python
# def Rjopt(DECISION_THRESHOLD, theta, choice, pred_prob, X_test, pval = 0, demote = True):
#     upval = int(not pval) #Unprivileged
#     pred_prob = y_pred_prob.copy() #probabilities of getting output as 0 or favourable (high probability high case of 0 or fav)
#     s = X_test[choice]
    
#     flip_candidates = np.ones_like(pred_prob).astype(bool) if demote else s == upval #unprivileged group
#     np.sum(flip_candidates)
    
#     under_theta_index = np.where(
#             (np.abs(pred_prob - 0.5) < theta) & flip_candidates) 
#     #finding unprivileged & unfavourable within the threshold limit as defined by theta
    
#     pred_prob[under_theta_index] = 1 - pred_prob[under_theta_index] #flipping the probabilities
    
#     rocdata = pred_prob.copy()
#     rocbin=np.where(rocdata > DECISION_THRESHOLD, 0, 1)
    
#     fpr, tpr, _ = roc_curve(y_test, rocdata, pos_label=0)
#     print('ROC:', auc(fpr, tpr))


#     fpr, tpr, _ = roc_curve(y_test, y_pred_prob, pos_label=0)
#     print('base:', auc(fpr, tpr))
    
    
    
#     return rocbin, pred_prob
```


```python
D_Boundary = 0.5
theta = 0.1
penalise = True
pval = 0
upval = int(not pval) #Unprivileged
```


```python
biased_protected_groups=['EDUCATION']
```


```python
pred_prob = y_pred_prob.copy()

     #p
roc=pd.DataFrame()
roc_df = pd.DataFrame(pred_prob, columns=['pred_prob'])
roc_df['y_pred_original'] = y_pred_prob
roc_df['y_pred'] = y_pred
roc_df['y_test'] = y_test.reset_index(drop=True)
roc_df['S'] = X_test[choice].reset_index(drop=True)

print(roc_df.head())
print("\n")
```

       pred_prob  y_pred_original  y_pred  y_test  S
    0       0.97             0.97       0       0  0
    1       0.29             0.29       1       1  0
    2       0.92             0.92       0       0  0
    3       0.46             0.46       1       1  0
    4       0.91             0.91       0       0  0
    
    



```python
if penalise==True:
    RO_df = roc_df[(np.abs(pred_prob - 0.5) < theta)]
else:
    RO_df = roc_df[(np.abs(pred_prob - 0.5) < theta) & (y_pred==fav)]

```


```python
RO_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pred_prob</th>
      <th>y_pred_original</th>
      <th>y_pred</th>
      <th>y_test</th>
      <th>S</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>0.46</td>
      <td>0.46</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.54</td>
      <td>0.54</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.42</td>
      <td>0.42</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.57</td>
      <td>0.57</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.60</td>
      <td>0.60</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
pval_fav = RO_df[(RO_df['S']==0) & (RO_df['y_pred']==0)]
pval_ufav = RO_df[(RO_df['S']==0) & (RO_df['y_pred']==1)]
upval_fav = RO_df[(RO_df['S']==1) & (RO_df['y_pred']==0)]
upval_ufav = RO_df[(RO_df['S']==1) & (RO_df['y_pred']==1)]
```


```python
pval_fav['pred_prob'] = 1- pval_fav['pred_prob']
upval_ufav['pred_prob'] = 1-upval_ufav['pred_prob']
```


```python
RO_changed = pd.concat([pval_fav, pval_ufav, upval_fav, upval_ufav])
RO_changed.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pred_prob</th>
      <th>y_pred_original</th>
      <th>y_pred</th>
      <th>y_test</th>
      <th>S</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>10</th>
      <td>0.46</td>
      <td>0.54</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.43</td>
      <td>0.57</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.40</td>
      <td>0.60</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>0.46</td>
      <td>0.54</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>143</th>
      <td>0.50</td>
      <td>0.50</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = roc_df
df.loc[list(RO_changed.index), 'pred_prob']=RO_changed['pred_prob']
```


```python
plt.figure(figsize=(10,6))
p1=sns.kdeplot(df['pred_prob'], shade=True, color="r")
p1=sns.kdeplot(df['y_pred_original'], shade=True, color="b")
plt.title('Density plot before and after ROC for {}'.format(choice), fontsize=16)
plt.show()
```


    
![png](output_119_0.png)
    



```python
df['rocdata']=df['pred_prob'].copy()
df['rocbin']=np.where(df['rocdata'] > 0.5, 0, 1)
```


```python
from sklearn.metrics import roc_curve, auc
print (choice)
fpr, tpr, _ = roc_curve(df['y_test'], df['y_pred_original'].values, pos_label=0)
ROC = auc(fpr, tpr)
print('Original:', ROC)


fpr, tpr, _ = roc_curve(df['y_test'], df['pred_prob'].values, pos_label=0)
base = auc(fpr, tpr)
print('After ROC:', base)

print('ratio', base/ROC)

print ()
```

    MARRIAGE_0
    Original: 0.7575541956676431
    After ROC: 0.7559316093181679
    ratio 0.9978581250572506
    



```python
tn_up, fp_up, fn_up, tp_up = confusion_matrix(df['y_test'][df['S']==upval], df['rocbin'][df['S']==upval]).ravel()
tn_p, fp_p, fn_p, tp_p = confusion_matrix(df['y_test'][df['S']==pval], df['rocbin'][df['S']==pval]).ravel()
Fullmodel = acf_fair_metrics(tn_up, fp_up, fn_up, tp_up, tn_p, fp_p, fn_p, tp_p)

tn_up, fp_up, fn_up, tp_up = confusion_matrix(df['y_test'][df['S']==upval], df['y_pred'][df['S']==upval]).ravel()
tn_p, fp_p, fn_p, tp_p = confusion_matrix(df['y_test'][df['S']==pval], df['y_pred'][df['S']==pval]).ravel()
ROC = acf_fair_metrics(tn_up, fp_up, fn_up, tp_up, tn_p, fp_p, fn_p, tp_p)
```


```python
Fullmodel
```




    [('Equal Opps', 0.4641937145801134),
     ('PredEq', 0.008721905400872185),
     ('Equal Odds', 0.4729156199809855),
     ('DemoParity', 0.10144567794506595),
     ('AOD', 0.23645780999049276)]




```python
labels, Fullmodel1 = zip(*Fullmodel)
headers, ROC1 = zip(*ROC)
ROC2={'Metrics':headers, 
             'Full Model':list(Fullmodel1), 'ROC Fair Model':list(ROC1)}
ROC_table=pd.DataFrame.from_dict(ROC2)
```


```python
ROC_table
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Metrics</th>
      <th>Full Model</th>
      <th>ROC Fair Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Equal Opps</td>
      <td>0.464194</td>
      <td>0.364760</td>
    </tr>
    <tr>
      <th>1</th>
      <td>PredEq</td>
      <td>0.008722</td>
      <td>0.031727</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Equal Odds</td>
      <td>0.472916</td>
      <td>0.333034</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DemoParity</td>
      <td>0.101446</td>
      <td>0.048258</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AOD</td>
      <td>0.236458</td>
      <td>0.166517</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax = ROC_table.plot.bar(x='Metrics', rot=90, width = 0.7, color=['red', 'black'], figsize=(10,5), fontsize=12)
plt.suptitle('Absolute difference: {}'.format(choice),  
             fontsize=15, y=1)

patches, labels = ax.get_legend_handles_labels()
ax.legend(patches, labels, loc='upper right', fontsize=12)

ax.set_xlabel('Fairness Metrics', fontsize=15)
plt.show()
```


    
![png](output_126_0.png)
    



```python
import XAI_Prototype_Final
```


```python
from XAI_Prototype_Final import *
```


```python
!pip install pygam
```

    Requirement already satisfied: pygam in /opt/anaconda3/lib/python3.9/site-packages (0.8.0)
    Requirement already satisfied: progressbar2 in /opt/anaconda3/lib/python3.9/site-packages (from pygam) (4.2.0)
    Requirement already satisfied: future in /opt/anaconda3/lib/python3.9/site-packages (from pygam) (0.18.2)
    Requirement already satisfied: numpy in /opt/anaconda3/lib/python3.9/site-packages (from pygam) (1.21.5)
    Requirement already satisfied: scipy in /opt/anaconda3/lib/python3.9/site-packages (from pygam) (1.9.1)
    Requirement already satisfied: python-utils>=3.0.0 in /opt/anaconda3/lib/python3.9/site-packages (from progressbar2->pygam) (3.4.5)



```python
!pip install dice-ml
```

    Requirement already satisfied: dice-ml in /opt/anaconda3/lib/python3.9/site-packages (0.9)
    Requirement already satisfied: numpy in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (1.21.5)
    Requirement already satisfied: scikit-learn in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (1.0.2)
    Requirement already satisfied: h5py in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (3.7.0)
    Requirement already satisfied: jsonschema in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (4.16.0)
    Requirement already satisfied: pandas in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (1.4.4)
    Requirement already satisfied: tqdm in /opt/anaconda3/lib/python3.9/site-packages (from dice-ml) (4.64.1)
    Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in /opt/anaconda3/lib/python3.9/site-packages (from jsonschema->dice-ml) (0.18.0)
    Requirement already satisfied: attrs>=17.4.0 in /opt/anaconda3/lib/python3.9/site-packages (from jsonschema->dice-ml) (21.4.0)
    Requirement already satisfied: python-dateutil>=2.8.1 in /opt/anaconda3/lib/python3.9/site-packages (from pandas->dice-ml) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /opt/anaconda3/lib/python3.9/site-packages (from pandas->dice-ml) (2022.1)
    Requirement already satisfied: joblib>=0.11 in /opt/anaconda3/lib/python3.9/site-packages (from scikit-learn->dice-ml) (1.2.0)
    Requirement already satisfied: threadpoolctl>=2.0.0 in /opt/anaconda3/lib/python3.9/site-packages (from scikit-learn->dice-ml) (2.2.0)
    Requirement already satisfied: scipy>=1.1.0 in /opt/anaconda3/lib/python3.9/site-packages (from scikit-learn->dice-ml) (1.9.1)
    Requirement already satisfied: six>=1.5 in /opt/anaconda3/lib/python3.9/site-packages (from python-dateutil>=2.8.1->pandas->dice-ml) (1.16.0)



```python
dataacf['MARRIAGE_0'].astype(int)
```




    0        0
    1        0
    2        0
    3        0
    4        0
            ..
    29995    0
    29996    0
    29997    0
    29998    0
    29999    0
    Name: MARRIAGE_0, Length: 30000, dtype: int64




```python
target_variable = "default payment next month"
independent_features = ['LIMIT_BAL', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
       'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
       'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
       'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6', 'MARRIAGE_0']

data_new=dataacf[['default payment next month','LIMIT_BAL', 'EDUCATION', 'PAY_0', 'PAY_2', 'PAY_3',
       'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3',
       'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2',
       'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6', 'MARRIAGE_0']]
GAM1 = GAM(data_new,independent_features,target_variable)
GAM1.fit()
GAM_train_acc, GAM_test_acc, GAM_summary  = GAM1.predict()

print(f"Train Accuracy: {GAM_train_acc}\n")
print(f"Test Accuracy: {GAM_test_acc}\n")
# print('')
```

    Train Accuracy: 0.8215
    
    Test Accuracy: 0.8211666666666667
    



```python
GAM1.summary()
```

    LogisticGAM                                                                                               
    =============================================== ==========================================================
    Distribution:                      BinomialDist Effective DoF:                                    124.3446
    Link Function:                        LogitLink Log Likelihood:                                -10272.0833
    Number of Samples:                        24000 AIC:                                            20792.8557
                                                    AICc:                                           20794.1824
                                                    UBRE:                                               2.8705
                                                    Scale:                                                 1.0
                                                    Pseudo R-Squared:                                   0.1887
    ==========================================================================================================
    Feature Function                  Lambda               Rank         EDoF         P > x        Sig. Code   
    ================================= ==================== ============ ============ ============ ============
    s(0)                              [0.6]                20           11.2         0.00e+00     ***         
    s(1)                              [0.6]                20           1.0          5.09e-06     ***         
    s(2)                              [0.6]                20           9.1          0.00e+00     ***         
    s(3)                              [0.6]                20           7.3          1.09e-02     *           
    s(4)                              [0.6]                20           7.7          4.45e-03     **          
    s(5)                              [0.6]                20           7.0          4.27e-03     **          
    s(6)                              [0.6]                20           6.5          4.11e-02     *           
    s(7)                              [0.6]                20           6.5          1.60e-06     ***         
    s(8)                              [0.6]                20           9.9          1.33e-03     **          
    s(9)                              [0.6]                20           6.4          1.09e-01                 
    s(10)                             [0.6]                20           5.3          5.12e-02     .           
    s(11)                             [0.6]                20           7.1          5.91e-01                 
    s(12)                             [0.6]                20           6.8          8.25e-01                 
    s(13)                             [0.6]                20           5.3          4.09e-01                 
    s(14)                             [0.6]                20           3.3          1.73e-08     ***         
    s(15)                             [0.6]                20           3.0          8.62e-07     ***         
    s(16)                             [0.6]                20           4.0          1.57e-03     **          
    s(17)                             [0.6]                20           4.3          1.60e-01                 
    s(18)                             [0.6]                20           6.3          8.52e-02     .           
    s(19)                             [0.6]                20           5.3          4.90e-01                 
    s(20)                             [0.6]                20           1.0          1.06e-01                 
    intercept                                              1            0.0          8.93e-02     .           
    ==========================================================================================================
    Significance codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    WARNING: Fitting splines and a linear function to a feature introduces a model identifiability problem
             which can cause p-values to appear significant when they are not.
    
    WARNING: p-values calculated in this manner behave correctly for un-penalized models or models with
             known smoothing parameters, but when smoothing parameters have been estimated, the p-values
             are typically lower than they should be, meaning that the tests reject the null too readily.



```python
data_new['MARRIAGE_0']=data_new['MARRIAGE_0'].astype('int64',copy=False)
```


```python
data_new.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 22 columns):
     #   Column                      Non-Null Count  Dtype
    ---  ------                      --------------  -----
     0   default payment next month  30000 non-null  int64
     1   LIMIT_BAL                   30000 non-null  int64
     2   EDUCATION                   30000 non-null  int64
     3   PAY_0                       30000 non-null  int64
     4   PAY_2                       30000 non-null  int64
     5   PAY_3                       30000 non-null  int64
     6   PAY_4                       30000 non-null  int64
     7   PAY_5                       30000 non-null  int64
     8   PAY_6                       30000 non-null  int64
     9   BILL_AMT1                   30000 non-null  int64
     10  BILL_AMT2                   30000 non-null  int64
     11  BILL_AMT3                   30000 non-null  int64
     12  BILL_AMT4                   30000 non-null  int64
     13  BILL_AMT5                   30000 non-null  int64
     14  BILL_AMT6                   30000 non-null  int64
     15  PAY_AMT1                    30000 non-null  int64
     16  PAY_AMT2                    30000 non-null  int64
     17  PAY_AMT3                    30000 non-null  int64
     18  PAY_AMT4                    30000 non-null  int64
     19  PAY_AMT5                    30000 non-null  int64
     20  PAY_AMT6                    30000 non-null  int64
     21  MARRIAGE_0                  30000 non-null  int64
    dtypes: int64(22)
    memory usage: 5.0 MB



```python
CF2 = CF(data_new,independent_features,target_variable)
CF2.fit()
CF2.dice_ml()
```




    <dice_ml.explainer_interfaces.dice_random.DiceRandom at 0x7f94092d7d30>




```python
CF2.CF_EXP()
```

    100%|█████████████████████████████████████████████| 1/1 [00:00<00:00, 13.34it/s]

    No Counterfactuals found for the given configuration, perhaps try with different parameters... ; total time taken: 00 min 00 sec


    



    ---------------------------------------------------------------------------

    UserConfigValidationException             Traceback (most recent call last)

    /var/folders/lh/w6ds713n5v39n0thp4d8nw9h0000gn/T/ipykernel_4469/2187574784.py in <module>
    ----> 1 CF2.CF_EXP()
    

    ~/Downloads/PGP AI-DS/Quarter-3/Responsible AI/XAI_Prototype_Final.py in CF_EXP(self)
        251 
        252     def CF_EXP(self):
    --> 253         self.e1 = self.exp.generate_counterfactuals(self.X_test[3:4], total_CFs=4, 
        254                                                     desired_class="opposite",features_to_vary=self.independent_features[1:4])
        255         self.e1.visualize_as_dataframe(show_only_changes=True)


    /opt/anaconda3/lib/python3.9/site-packages/dice_ml/explainer_interfaces/explainer_base.py in generate_counterfactuals(self, query_instances, total_CFs, desired_class, desired_range, permitted_range, features_to_vary, stopping_threshold, posthoc_sparsity_param, proximity_weight, sparsity_weight, diversity_weight, categorical_penalty, posthoc_sparsity_algorithm, verbose, **kwargs)
        171                 **kwargs)
        172             cf_examples_arr.append(res)
    --> 173         self._check_any_counterfactuals_computed(cf_examples_arr=cf_examples_arr)
        174 
        175         return CounterfactualExplanations(cf_examples_list=cf_examples_arr)


    /opt/anaconda3/lib/python3.9/site-packages/dice_ml/explainer_interfaces/explainer_base.py in _check_any_counterfactuals_computed(self, cf_examples_arr)
        841                 break
        842         if no_cf_generated:
    --> 843             raise UserConfigValidationException(
        844                 "No counterfactuals found for any of the query points! Kindly check your configuration.")
        845 


    UserConfigValidationException: No counterfactuals found for any of the query points! Kindly check your configuration.



```python
full_model = IV_PDP(data_new,independent_features,target_variable)
full_model.fit()
full_model_predictions = full_model.predict()
```


```python
full_model.EDA_PLOT()
```


    
![png](output_139_0.png)
    



    
![png](output_139_1.png)
    



```python
full_model.IV_PLOT()
```


    
![png](output_140_0.png)
    



    
![png](output_140_1.png)
    



    
![png](output_140_2.png)
    



    
![png](output_140_3.png)
    



```python
full_model.PDP_PLOT()
```


    
![png](output_141_0.png)
    



```python
GAM.GAM_PLOT()
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    /var/folders/lh/w6ds713n5v39n0thp4d8nw9h0000gn/T/ipykernel_4469/1625227252.py in <module>
    ----> 1 GAM.GAM_PLOT()
    

    TypeError: GAM_PLOT() missing 1 required positional argument: 'self'



```python
def ret_tag(val):
        for i in range(10):
            if val in categories[i]:
                return tags[i]
        
def zero_list_maker(n):
        list_of_zeros = [0] * n
        return list_of_zeros
```


```python
def bar_width_per_quantile2(SCQ_view, label_filter):
    view_filtered = SCQ_view[SCQ_view['default payment next month'] == label_filter]      
    view_filtered['Tag'] = view_filtered['Score2'].map(lambda x: ret_tag(x))
    len_view_filtered = len(view_filtered)
    view_filtered['ID']=view_filtered.index
    count_pertag_filtered = view_filtered[['ID', 'Tag']].groupby(['Tag']).count().rename(columns={'ID': 'Count'})
    count_pertag_filtered['Perc'] = count_pertag_filtered['Count'] / len(SCQ_view) * 100

    Amt = view_filtered[['ID', 'Tag', 'Amount']].groupby(['Tag'])['Amount'].sum()
    Amt = (Amt/1000).to_list()
    sc = count_pertag_filtered['Perc'].tolist()
    sc = zero_list_maker(10 - len(sc)) + sc 
    return sc, Amt  
```


```python
SCQ2 = SCQ(data_new,independent_features,target_variable)
SCQ2.fit()
SCQ_predictions = SCQ2.predict()
SCQ_view = SCQ2.create_view("LIMIT_BAL",'Score',['default payment next month','Score','Amount'])

#2 For ret_tags, zero_lists and Categories
i=5
cuts_by_quantile = pd.qcut(SCQ_view['Score2'], 11, duplicates='drop') 
categories = cuts_by_quantile.value_counts().index.categories
left_bounds = categories.left
right_bounds = categories.right
tags = range(1, 11)

#3 For class bar_width_per_quantile2
sc1, amt1 = bar_width_per_quantile2(SCQ_view, 1)
sc0, amt0 = bar_width_per_quantile2(SCQ_view, 0)

#Defining dataframes for plotting
name = [str(left_bounds[i])+'-'+str(right_bounds[i]) for i in range(10)]

data_p = [(name[i], sc1[i], sc0[i]) for i in range(10)]
data_amt = [(name[i], amt1[i], amt0[i]) for i in range(10)]

df1 = pd.DataFrame(columns=["Range","Label 1", "Label 0"],data=data_p)
df2 = pd.DataFrame(columns=["Range", 'Amount:1', "Amount:0"],data=data_amt)
```


```python
Show_quantile_label(df1,None)
```


    
![png](output_146_0.png)
    



```python
Show_quantile_label(None,df2)
```


    
![png](output_147_0.png)
    



```python

```
